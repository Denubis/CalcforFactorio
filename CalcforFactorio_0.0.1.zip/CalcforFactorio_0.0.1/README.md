# SQLforFactorio

By: Brian Ballsun-Stanton

SQLite icon from their logo (public domain), downloaded from: https://www.nuget.org/packages?q=sqlite
Gnome Terminal icon (C) GNOME developers, under a CC-BY-SA